# ToDo
1. Unit Tests!!!
1. Show last topic inline keyboard button for publish
1. Add names for subscriptions and show them on chart legends instead topic
1. Add chart button params to configure:
    - min value for Y axis (autoscale by default)
    - user datetime format for X axis
1. Editable subscription stored data
    - Subscriptions -> /topic -> Stored data (count) ->
        - Print stored data
        - Clear older than month (count)
        - Clear older than week (count)
        - Clear all stored data (count)
        - Back
1. Configurable user timezone
